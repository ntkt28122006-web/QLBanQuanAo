﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace QLBanQuanAo
{
    public partial class frmAdminProduct : Form
    {
        public frmAdminProduct()
        {
            InitializeComponent();
        }

        private void lblPageDescription_Click(object sender, EventArgs e)
        {

        }

        private void pnlProductInfo_Paint(object sender, PaintEventArgs e)
        {

        }


        private void btnResetFilter_Click(object sender, EventArgs e)
        {

        }

        private void btnSearchProduct_Click(object sender, EventArgs e)
        {

        }

        private string selectedImagePath = "";
        private void btnChooseImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Chọn hình ảnh sản phẩm";
                dialog.Filter =
                    "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    selectedImagePath = dialog.FileName;

                    using (Image source = Image.FromFile(selectedImagePath))
                    {
                        picProductImage.Image = new Bitmap(source);
                    }
                }
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {

        }

        private void btnClearProduct_Click(object sender, EventArgs e)
        {
            txtProductId.Clear();
            txtProductName.Clear();
            txtProductBrand.Clear();
            txtProductDescription.Clear();

            cboCategory.SelectedIndex = -1;
            cboProductStatus.SelectedIndex = -1;

            numProductPrice.Value = 0;
            numProductSalePrice.Value = 0;

            chkIsHot.Checked = false;
            chkIsSale.Checked = false;

            selectedImagePath = "";

            if (picProductImage.Image != null)
            {
                picProductImage.Image.Dispose();
                picProductImage.Image = null;
            }

            dgvProducts.ClearSelection();
            txtProductName.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblProductName_Click(object sender, EventArgs e)
        {

        }

        private void txtProductId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtProductName_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtProductBrand_TextChanged(object sender, EventArgs e)
        {

        }

        private void numProductPrice_ValueChanged(object sender, EventArgs e)
        {

        }

        private void pnlProductBody_Paint(object sender, PaintEventArgs e)
        {

        }

        private void numProductSalePrice_ValueChanged(object sender, EventArgs e)
        {

        }

        private void lblProductStatus_Click(object sender, EventArgs e)
        {

        }

        private void txtProductDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkIsHot_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkIsSale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtSearchProduct_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboFilterCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cboFilterStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
