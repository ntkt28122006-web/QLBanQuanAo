﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBanQuanAo
{
    public partial class frmCategory : Form
    {
        public frmCategory()
        {
            InitializeComponent();
        }

        private void lblCategoryDescription_Click(object sender, EventArgs e)
        {

        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {

        }

        private void btnClearCategory_Click(object sender, EventArgs e)
        {

        }

        private void dgvCategories_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtCategoryId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCategoryName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCategorySlug_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboParentCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chkCategoryActive_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
