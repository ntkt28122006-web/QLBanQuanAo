﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBanQuanAo
{
    public partial class frmAdminOrder : Form
    {
        public frmAdminOrder()
        {
            InitializeComponent();
        }

        private void lblOrderTitle_Click(object sender, EventArgs e)
        {

        }

        private void txtSearchOrder_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboFilterStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cboFilterPaymentStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dtpFromDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dtpToDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnResetOrderFilter_Click(object sender, EventArgs e)
        {

        }

        private void btnSearchOrder_Click(object sender, EventArgs e)
        {

        }

        private void btnViewOrderDetail_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateOrderStatus_Click(object sender, EventArgs e)
        {

        }

        private void btnPrintInvoice_Click(object sender, EventArgs e)
        {

        }

        private void dgvOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvOrderDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
