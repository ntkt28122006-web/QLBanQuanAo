﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBanQuanAo
{
    public partial class frmAdminDashboard : Form
    {
        public frmAdminDashboard()
        {
            InitializeComponent();
        }

        private void lblCustomerManagementTitle_Click(object sender, EventArgs e)
        {

        }







        private void btnSearchCustomer_Click(object sender, EventArgs e)
        {

        }
        private void btnLockCustomer_Click(object sender, EventArgs e)
        {

        }

        private void btnUnlockCustomer_Click(object sender, EventArgs e)
        {

        }


        private void btnRefreshCustomer_Click(object sender, EventArgs e)
        {

        }

        private void txtSearchCustomer_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboFilterCustomerStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtDetailCustomerEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblDetailCustomerPhone_Click(object sender, EventArgs e)
        {

        }

        private void txtDetailCustomerId_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblDetailCustomerName_Click(object sender, EventArgs e)
        {

        }

        private void pnlCustomerList_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
